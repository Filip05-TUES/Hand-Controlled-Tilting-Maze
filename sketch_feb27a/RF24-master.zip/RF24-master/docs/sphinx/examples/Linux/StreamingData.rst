StreamingData.cpp
==================

.. literalinclude:: ../../../../examples_linux/streamingData.cpp
    :lines: 7-
    :linenos:
    :lineno-match:
