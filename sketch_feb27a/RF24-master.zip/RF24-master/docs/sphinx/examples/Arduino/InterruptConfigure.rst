InterruptConfigure.ino
======================

.. literalinclude:: ../../../../examples/InterruptConfigure/InterruptConfigure.ino
    :lines: 7-
    :linenos:
    :lineno-match:
